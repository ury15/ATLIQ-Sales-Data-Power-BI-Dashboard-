## ATLIQ Sales Insight Project - POWER BI Dashboard 

# The project zip file contains --

1. The data source file - 'db_dump_version_2.sql'.

2. Power BI Dashboard file - 'Sales Insight.pbix'.

3. Dashboard Visualization & schema Screenshots -
   - 'Table Schema'
   - 'Key Insights'
   - 'Performance Analysis'
   - 'Profit Analysis'


## END